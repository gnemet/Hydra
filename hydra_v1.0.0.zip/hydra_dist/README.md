# 🐉 Hydra Deployment

## Quick Start
1. Edit `.env` with your target NAS IP and settings.
2. Ensure you have static IP configured if using direct UTP connection.
3. Run:
   ./parallel.sh

## Requirements
- Linux OS (x86_64)
- curl, grep, awk, split (Standard on most Linux distros)
